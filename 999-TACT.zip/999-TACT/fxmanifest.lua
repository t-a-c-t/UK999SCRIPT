fx_version 'cerulean'
game 'gta5'

author 'TACT-Development'
description 'A simplified 999 call system for vMenu-based FiveM servers.'
version '1.0.0'


client_scripts {
    'client.lua',  
}

server_scripts {
    'server.lua',  
}


dependencies {
    'vMenu'
}


shared_scripts {
    'config.lua'  
}

lua54 'yes'  -- Enable Lua 5.4 if supported
