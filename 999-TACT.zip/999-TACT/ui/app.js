let notificationTimeout;

window.addEventListener("message", (event) => {
    const { type, title, text, duration, sound } = event.data;

    if (type === "notify") {
        const notification = document.getElementById("notification");
        const notifyTitle = document.getElementById("notify-title");
        const notifyText = document.getElementById("notify-text");
        const alertSound = document.getElementById("alert-sound");

        // Set notification content
        notifyTitle.textContent = title;
        notifyText.textContent = text;

        // Play alert sound
        alertSound.play();

        // Show notification
        notification.classList.add("active");

        // Hide notification after the specified duration
        clearTimeout(notificationTimeout);
        notificationTimeout = setTimeout(() => {
            notification.classList.remove("active");
        }, duration * 1000);
    }
});
