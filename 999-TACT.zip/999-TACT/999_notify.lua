-- 999_notify.lua by t.a.c.t this is open-source and can be changed to your liking.
-- This script is a simple 999 emergency call system for FiveM servers.
-- It allows players to send a 999 emergency call to all LEOs with a specific ACE permission.
-- The call includes the caller's name, location, and message.
-- LEOs with the ACE permission will receive a notification with the caller's information.

local acePerm = "leo.role"  -- ACE permission required to receive 999 alerts
local alertDuration = 10    -- Duration of notification (in seconds)
local alertSound = "CHAR_CALL911"  -- GTA default alert sound (can be changed)

RegisterCommand("999", function(source, args)
    if source == 0 then
        print("This command can only be used in-game.")
        return
    end

    local message = table.concat(args, " ")
    if message == "" then
        TriggerClientEvent("chatMessage", source, "^1[ERROR] ^7Usage: /999 <message>")
        return
    end

    local playerName = GetPlayerName(source)
    local playerCoords = GetEntityCoords(GetPlayerPed(source))
    local streetHash, crossHash = GetStreetNameAtCoord(playerCoords.x, playerCoords.y, playerCoords.z)
    local streetName = GetStreetNameFromHashKey(streetHash)
    local crossStreetName = GetStreetNameFromHashKey(crossHash)
    local location = crossStreetName ~= "" and (streetName .. " & " .. crossStreetName) or streetName

    -- Send notification to all LEOs with the ACE permission
    TriggerClientEvent("999_notify:sendNotification", -1, {
        name = playerName,
        id = source,
        message = message,
        location = location
    })
end)

-- ACE Permission Check on Client Side
RegisterNetEvent("999_notify:sendNotification")
AddEventHandler("999_notify:sendNotification", function(data)
    if IsPlayerAceAllowed(PlayerId(), acePerm) then
        SendNUIMessage({
            type = "notify",
            title = "999 Emergency Call",
            text = "Caller: " .. data.name .. " (ID: " .. data.id .. ")\n" ..
                   "Location: " .. data.location .. "\n" ..
                   "Message: " .. data.message,
            duration = alertDuration,
            sound = alertSound
        })
    end
end)
